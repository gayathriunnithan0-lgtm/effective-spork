# Finance & Accounting Portfolio — Gayathri Unnithan

Four hands-on Excel projects covering the three areas I'm building toward:
**bookkeeping (freelance), financial analysis, and FP&A / MIS reporting.**
Every workbook is formula-driven — statements recalculate live when you open
them in Excel, so you can trace any number back to its source.

| # | Project | File | Skills demonstrated |
|---|---------|------|---------------------|
| 1 | Small Business Bookkeeping System — *Sunrise Bakery* | `01-Bookkeeping-Sunrise-Bakery.xlsx` | Double-entry journal, ledger, trial balance, P&L, balance sheet, GST (input/output), linked statements with balance checks |
| 2 | 5-Year Financial Statement Analysis — *Infosys Ltd* | `02-Financial-Analysis-Infosys.xlsx` | Common-size analysis, YoY growth, CAGR, ratio analysis (profitability, leverage, coverage), cited real data, charts |
| 3 | Budget vs Actual Variance Analysis — *Nova Retail Pvt Ltd* | `03-Budget-Variance-FY2025-26.xlsx` | FP&A variance reporting, fav/unfav conventions, conditional formatting, EBITDA bridge, KPI dashboard |
| 4 | Accounts Receivable Aging & Collections — *BrightPath Solutions* | `04-AR-Aging-Collections.xlsx` | AR aging (SUMIFS/COUNTIFS), provisioning policy, customer risk tiering, collections worklist, DSOS, dashboard |

## How the projects connect to real work

- **Project 1** is the full monthly bookkeeping cycle I would run for a freelance
  client: transactions in, GST summary and financial statements out, with
  built-in checks (Dr = Cr, Assets = Liabilities + Equity) so errors surface
  immediately.
- **Project 2** shows I can work with real published financial data: pulling
  five years of P&L, standardising it, and turning it into ratios and written
  observations a manager can read in two minutes. Data is sourced and cited
  (smart-investing.in, stockscans.in — accessed Sep 2026); the FY2026
  exceptional-item gap is disclosed, not hidden.
- **Project 3** is the monthly MIS/FP&A pack: budget vs actual by line with the
  favourable/unfavourable convention used in real reporting, plus an executive
  dashboard telling one coherent story (revenue ahead, EBITDA slightly behind
  because marketing overspend didn't convert).
- **Project 4** is the receivables routine that keeps cash coming in: aging
  buckets, provisioning, who to chase first, and how long sales take to convert
  to cash (DSOS).

## Tools

- Microsoft Excel (formulas, SUMIF/SUMIFS/COUNTIFS/MAXIFS, IF logic, conditional
  formatting, native charts) — built with openpyxl; all formulas set to
  recalculate on open.
- Every workbook has a **README sheet** explaining method, assumptions, and how
  to read it.

## Notes

- Companies in projects 1, 3 and 4 are fictional; figures are realistic dummy
  data generated with a fixed seed. Project 2 uses real Infosys consolidated
  data as cited on its README sheet.
- Percentages, currency formats, and the ₹/Rs conventions are documented on
  each workbook's README sheet.
- Educational analysis only — nothing here is investment advice.
